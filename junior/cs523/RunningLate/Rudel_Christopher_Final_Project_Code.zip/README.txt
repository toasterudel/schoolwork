This is the code for my final project, the Running Late app.
There are no special build instructions, simply load the app into Xcode and press compile.
The app has one caveat when testing in the simulator. The app sets up a message through iMessage when the alarm goes off, and the simulator does not support iMessage through an app the way I called it. In my video I showed that the iMessage is fully functional, I apologize for the grading inconvenience.
