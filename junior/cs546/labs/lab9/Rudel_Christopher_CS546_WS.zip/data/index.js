const prime = require('./prime');

module.exports = {
    prime: prime
};