const mainRoute = require("./main");
//const searchRoute = require("./search");
//const detailRoute = require("./details");



module.exports = {
    main: mainRoute,
   // search: searchRoute,
   // details: detailRoute
};