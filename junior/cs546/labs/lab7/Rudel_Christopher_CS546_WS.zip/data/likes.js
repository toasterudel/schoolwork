/*
*   Christopher Rudel
*   CS546
*   index.js
*   lab7
*   I pledge my honor that I have abided by the Stevens Honor System
*/

/*

I didnt start the assignment until late and I didn't know how much time it would take up 
So I didn't have time to implement this

*/