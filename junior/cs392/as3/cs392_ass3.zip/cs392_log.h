/*
*   Christopher Rudel
*   Professor Xu
*   CS 392
*   cs392_log.h
*   I pledge my honor that I have abided by the Stevens Honor System
*
*/

#ifndef CS392_LOG_H
#define CS392_LOG_H

#include <stdio.h>
void writeToLog(char*);


#endif