/*
*   Christopher Rudel
*   Professor Xu
*   CS 392
*   cs392_string.h
*   I pledge my honor that I have abided by the Stevens Honor System
*
*/

#ifndef CS392_STRING_H  //if the header file is not defined,
#define CS392_STRING_H  //declare the header file

void *cs392_memcpy (void *, void *, unsigned);
unsigned cs392_strlen(char *);

#endif
